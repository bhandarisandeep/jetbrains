n1 = int(input())
n2 = int(input())
print(max(n1, n2))
print(min(n1, n2))
