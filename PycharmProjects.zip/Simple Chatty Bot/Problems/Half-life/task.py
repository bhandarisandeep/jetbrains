# half life
initial_life = int(input())
residue_life = int(input())
half_life_days = 12

while (initial_life / 2) >= residue_life:
    half_life_days += 12
    initial_life /= 2
print(half_life_days)
