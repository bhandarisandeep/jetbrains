principal_amount = int(input())
intrest = 0
time_years = 0
while (principal_amount) < 700000:
    intrest = (principal_amount * (7.1/100))
    principal_amount += intrest
    # print(intrest)
    time_years += 1

print(time_years)
