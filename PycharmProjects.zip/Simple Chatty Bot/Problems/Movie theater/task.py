# put your python code here
hall_count = int(input())
viewers_count = int(input())
check_accomodation = int(input())

if((hall_count * viewers_count) >= check_accomodation):
    print("True")
else:
    print("False")
