# Figure out how many moves a chess king can make from a square
# with given coordinates.
# The coordinates are numbers between 1 and 8 inclusively.
# The first number indicates a column,
# the second one indicates a row.
# The king moves one square in any direction (horizontally, vertically, or diagonally). Other rules, as well as special moves, are not taken into account.
#
#
# Sample Input:
# 3
# 2
# Sample Output:
# 8
#

kx = int(input())
ky = int(input())


if 1 < kx < 8 and 1 < ky < 8:
    print(8)
elif 1 < ky < 8 and (kx == 1 or kx == 8):
    print(5)
elif 1 < kx < 8 and (ky == 1 or ky == 8):
    print(5)
elif (kx == 1 or kx == 8) and (ky == 1 or ky == 8):
    print(3)
else:
    print("wrong input")
