name = input()
party_list = list()
while name != ".":
    party_list.append(name)
    name = input()
print(party_list)
print(len(party_list))
