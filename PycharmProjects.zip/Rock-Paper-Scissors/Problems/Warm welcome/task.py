def get_bonus(salary, percentage=35):
    bonus = int(salary) * int(percentage) * 0.01
    return int(bonus)

# print(get_bonus(100))
