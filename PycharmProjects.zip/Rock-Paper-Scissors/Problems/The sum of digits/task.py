digit = int(input())
sum = 0
for i in range(len(str(digit))):
    sum += digit % 10
    digit //= 10
print(sum)
