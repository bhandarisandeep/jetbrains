# put your python code here
total_sum = 0
new_list = list()
square = 0
while True:
    i = int(input())
    total_sum += i
    new_list.append(i)
    if total_sum == 0:
        break
for i in new_list:
    if new_list[0] == 0:
        break
    else:
        square += (i ** 2)
print(square)
