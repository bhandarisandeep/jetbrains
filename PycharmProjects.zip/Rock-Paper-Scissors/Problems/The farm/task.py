price = {23 : "chicken",
        678 : "goat",
        1296 : "pig" ,
        3848 : "cow" ,
        6769 : "sheep"
         }
# money = int(input("input the price that you have : \n"))
money = int(input())
# print(price.get(money, "not available"))
if money >= 23:

        if  money > 6768:
            print(f'{money // 6769} {price[6769]}' if (money // 6769) != 0 else "")
        elif money > 3847:
            print(f'{money // 3848} {price[3848]}' if (money // 3848) == 1 else f'{money // 3848} {price[3848]}s' if (money // 3848) > 1  else "")
        elif money > 1295:
            print(f'{money // 1296} {price[1296]}' if (money // 1296) == 1 else f'{money // 1296} {price[1296]}s' if (money // 1296) > 1  else "")
        elif money > 677:
            print(f'{money // 678} {price[678]}' if (money // 678) == 1 else f'{money // 678} {price[678]}s' if (money // 678) > 1  else "")
        elif money > 22:
            print(f'{money // 23} {price[23]}' if (money // 23) == 1 else f'{money // 23} {price[23]}s' if (money // 23) > 1  else "")

else:
    print("None")
# for key,value in price:
# print(price.items())
# print(price)
