# put your python code here
# Operations are: +, -, /, *, mod, pow, div.
operation_available = {"+", "-","*", "/", "mod", "pow", "div"}

n1 = float(input())
n2 = float(input())
operation = input()

if operation in operation_available:
    if operation == "+":
        print(n1 + n2)
    elif operation == "-":
        print(n1 - n2)
    elif operation == "/":
        if n2 != 0:
            print(n1 / n2)
        else:
            print("Division by 0!")
    elif operation == "mod":
        if n2 != 0:
            print(n1 % n2)
        else:
            print("Division by 0!")
    elif operation == "pow":
        print(n1 ** n2)
    elif operation == "div":
        if n2 != 0:
            print(n1 // n2)
        else:
            print("Division by 0!")
    elif operation == "*":
        print(n1 * n2)
else:
    print("Choose correct operator")


