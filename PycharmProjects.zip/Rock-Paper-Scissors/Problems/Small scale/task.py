value = input()
number_list = list()
while value != ".":
    number_list.append(float(value))
    value = input()

print(sorted(number_list)[0])
