x = float(input())
y = float(input())
print(f'I' if x > 0 and y > 0 else f'II' if x < 0 and y > 0 else f'IV' if x > 0 and y < 0 else f'III')
