army_size = int(input())
print(f'no army' if army_size < 1 else 'few' if army_size < 10 else 'pack' if army_size < 50 else 'horde' if army_size < 500 else 'swarm' if army_size < 1000 else 'legion')
