offset = float(input())
print("Tuesday" if (-10.5 < offset < 13.5) else "Monday" if offset < -10.5 else "Wednesday" if offset >= 13.5 else "wronf offset")
