user_word = input()
snake_string = ""
for letter in user_word:
    if str.islower(letter):
        snake_string += letter
    else:
        snake_string += "_" + str.lower(letter)
print(snake_string)
