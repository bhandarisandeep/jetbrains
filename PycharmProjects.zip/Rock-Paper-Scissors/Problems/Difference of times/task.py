# put your python code here
def time_sec_gap(h1, m1, s1, h2, m2 ,s2):
    if h1 == h2:
        if s2 < s1:
            m2 -= 1
            s2 += 60
        # print(h1, m1, s1, h2, m2, s2)
        return (m2 - m1) * 60 + s2-s1

    elif h2 > h1:

        if m2 < m1:
            h2 -= 1
            m2 += 60
        if s2 < s1:
            m2 -= 1
            s2 += 60
        # print(h1, m1, s1, h2, m2, s2)
        return (h2 - h1) * 3600 + (m2 - m1) * 60 + s2-s1
    else:
        return None


h1 = int(input())
m1 = int(input())
s1 = int(input())
h2 = int(input())
m2 = int(input())
s2 = int(input())

time_sec_gap(h1, m1, s1, h2, m2, s2)
print(time_sec_gap(h1, m1, s1, h2, m2, s2))

# hour = int(input())
# minute = int(input())
# second = int(input())
# first_total = (hour * 3600) + (minute * 60) + second
#
# hour1 = int(input())
# minute1 = int(input())
# second1 = int(input())
# first_total1 = (hour1 * 3600) + (minute1 * 60) + second1
#
# print(first_total1 - first_total)
