vovel = ['a','e','i','o','u']
consonant = list("bcdfghjklmnpqrstvwxyz")
userinput = list(input())
for i in userinput:
    if i in vovel:
        # print(i)
        print("vowel")
    elif i in consonant:
        print("consonant")
    else:
        break
