# taking salary input

salary = int(input())
if salary >= 132407:
    tax = salary * .28
    print(f'The tax for {salary} is 28%. That is {tax:.0f} dollars!')
elif salary >= 42708:
    tax = salary * .25
    print(f'The tax for {salary} is 25%. That is {tax:.0f} dollars!')
elif salary >= 15528:
    tax = salary * .15
    print(f'The tax for {salary} is 15%. That is {tax:.0f} dollars!')
else:
    tax = salary * 0
    print(f'The tax for {salary} is 0%. That is {tax:.0f} dollars!')
