food_item = ("pizza" ,"salad", "soup")
pizza = "Margarita, Four Seasons, Neapoletana, Vegetarian, Spicy"
salad = "Caesar salad, Green salad, Tuna salad, Fruit salad"
soup = "Chicken soup, Ramen, Tomato soup, Mushroom cream soup"

user_want_to_eat = input()
if user_want_to_eat in food_item:
    if user_want_to_eat == "pizza":
        print(pizza)
    elif user_want_to_eat == "salad":
        print(salad)
    elif user_want_to_eat == "soup":
        print (soup)
else:
    print("Sorry, we don't have it in the menu")

