spin = input()
ec = input()

print("Strange Quark" if spin == "1/2" and ec == "-1/3"
      else "Charm Quark" if spin == "1/2" and ec == "2/3"
      else "Electron Lepton" if spin == "1/2" and ec == "-1"
      else "Muon Lepton" if spin == "1/2" and ec == "0"
      else "Photon Boson" if spin == "1" and ec == "0"
      else "Wrong input")
