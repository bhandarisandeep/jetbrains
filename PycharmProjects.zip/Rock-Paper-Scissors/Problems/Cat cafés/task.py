cafe = input()
cafed = {}
while cafe != "MEOW":
    temp_list = cafe.split()
    try:
        cafed[temp_list[0]] = temp_list[1]
    except IndexError:
        cafed[temp_list[0]] = 0
    cafe = input()
for key,value in cafed.items():
    maxv = value
    maxk = key
    for i,v in cafed.items():
         if int(maxv) < int(v):
            maxv = v
            maxk = i
print(maxk)



