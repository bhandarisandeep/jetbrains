# numbers = [1234, 5678, 90]
# # save this list in `file_with_list.txt`
# fileopen = open('file_with_list.txt', 'w')
# for i in numbers:
#     fileopen.write(str(i))
with open('file_with_list.txt', 'a') as j:
    j.write('[1234, 5678, 90]')
