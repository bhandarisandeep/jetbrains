# read animals.txt
# and write animals_new.txt
file = open('animals.txt', 'r')
aimals = file.readlines()
# print(aimals)
file.close()
animals = []
file2 = open('animals_new.txt', 'w+')
for index,i in enumerate(aimals):
    # print(i)
    i = i.replace('\n', " ")
    # print(i)
    animals.append(i)
# print(animals)
file2.writelines(animals)
file2.close()

