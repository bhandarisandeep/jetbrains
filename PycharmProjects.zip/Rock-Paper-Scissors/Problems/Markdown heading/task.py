def heading(heading,level=1):
    if level in range(1,7):
        # print("#" * level + " " + heading)
        return "#" * level + " " + heading
    elif level < 1:
        # print("#" * 1 + " " + heading)
        return "#" * 1 + " " + heading
    else:
        # print("#" * 6 + " " + heading)
        return "#" * 6 + " " + heading

# heading("A")      # Returns "# A"
# heading("A", 3)   # Returns "### A"
# heading("A", 1)   # Returns "# A"
# heading("A", 0)   # Returns "# A"
# heading("A", 10)  # Returns "###### A"
