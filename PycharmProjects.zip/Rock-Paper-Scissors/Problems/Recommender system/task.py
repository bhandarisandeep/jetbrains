age_movie = {"60": "Breakfast at Tiffany's",
             "40": "Pulp Fiction",
             "25": "Matrix",
             "16": "Trainspotting",
             "0": "Lion King"}
age = int(input())
for i, movie in age_movie.items():
    agenew = int(i)
    # print(agen)
    if age > agenew:
        print(movie)
        break
