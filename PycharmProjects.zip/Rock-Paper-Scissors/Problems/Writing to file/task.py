f_name = "test.txt"

my_string = "A string to be written to a file!"
file1 = open(f_name, 'w')
print("A string to be written to a file!", file=file1)
file1.close()
