# Save the input in this variable
ticket = int(input())

# Add up the digits for each half
half1 = (ticket // 1000)
half2 = (ticket % 1000)

print(half1)
print(half2)

half1 = (half1 % 10) + (half1 // 100) + ((half1 % 100) // 10)
half2 = (half2 % 10) + (half2 // 100) + ((half2 % 100) // 10)

print(half1)
print(half2)
# Thanks to you, this code will work
if half1 == half2:
    print("Lucky")
else:
    print("Ordinary")
