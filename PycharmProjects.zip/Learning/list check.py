list_out_of_string = list("asd")
print(list_out_of_string)
