# print('%.3f' % (10/3))
# print(round(10/3,3))

# print('Mix {}, {} and a {} to make an ideal omelet.'.format(input("egg number") + 'eggs', input("gm of milk") + 'g of milk', 'pinch of salt'))

name = 'Elizabeth II'
title = 'Queen of the United Kingdom and the other Commonwealth realms'
reign = 'the longest-lived and longest-reigning British monarch'
f'{name}, the {title}, is {reign}.'

print(f'{name}, the {title}, is {reign}.')
