import string
print(string.digits)
print(string.ascii_lowercase)

print(string.ascii_uppercase)
