number = float(input())
decimal_point = int(input())
print(f'{number:.{decimal_point}f}')
