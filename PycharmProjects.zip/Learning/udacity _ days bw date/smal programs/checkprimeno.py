## Your code should check if each number in the list is a prime number
check_prime = [26, 39, 51, 53, 57, 79, 85, 7]

## write your code here
## HINT: You can use the modulo operator to find a factor

isprime = True
for num in check_prime:
    count = 0
    for i in range(1, num//2 + 1):
        if num % i == 0:
            count += 1
        if count > 1:
            # print("{} is NOT a prime number, because {} is a factor of {}".format(num,i,num))
            isprime = False
            break
    # print(num)
    # print("count" + str(count))
    print(f'{num} IS a prime number' if isprime else "{} is NOT a prime number, because {} is a factor of {}".format(num,i,num))
