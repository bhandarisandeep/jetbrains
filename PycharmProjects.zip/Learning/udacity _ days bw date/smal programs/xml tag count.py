tokens = ['<greeting>', 'Hello World!', '</greeting>']
count = 0
for tag in tokens:
    if "<" and ">" in tag:
        count += 1

# write your for loop here


print(count)
