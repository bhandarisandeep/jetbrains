cast_names = ["Barney", "Robin", "Ted", "Lily", "Marshall"]
cast_heights = [72, 68, 72, 66, 76]
cast = {}
for i in zip(cast_names,cast_heights):
    cast[i[0]] = i[1]
print(cast)
