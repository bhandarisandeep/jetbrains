#
# An anagram is a word (or phrase) that is formed by rearranging the letters of another word (or phrase).
#
# For example:
#
# "rat" is an anagram of "art"
# "alert" is an anagram of "alter"
# "Slot machines" is an anagram of "Cash lost in me"
# Your function should take two strings as input and return True if the two words are anagrams and False if they are not.
#
# You can assume the following about the input strings:
#
# No punctuation
# No numbers
# No special characters
# Note - You can use built-in methods len(), lower() and sort() on strings.


def anagram_checker(str1, str2):

    """
    Check if the input strings are anagrams of each other

    Args:
       str1(string),str2(string): Strings to be checked
    Returns:
       bool: Indicates whether strings are anagrams
    """

    # TODO: Write your solution here
    str1 = str1.replace(" ", "").lower()
    str2 = str2.replace(" ", "").lower()

    # Compare the length of both strings
    if len(str1) == len(str2):
        # Sort each string and compare
        if sorted(str1) == sorted(str2):
            return True

    return False

print(anagram_checker('hello','lolhe'))
