# in this code we will create a linked list

class Node:
    def __init__(self, value):  # defining the consturctors
        self.value = value  # assignig the data in the node.
        self.next = None  # assigning None since it is not pointing to any other link.


head = Node(2)  # defing the head node. always rember the head.
"""
Now to assign the next node in the linked list we hace to methods:
1. reinitialising the node againwith a new head variable like:
    head1 = Node(3)
2. Simply we can use the address part of head variable to define a new node like:
    head.next = Node(3)
3. so printing head1.value is same as head.next.value
"""
head.next = Node(3)
head.next.next = Node(4)
head.next.next.next = Node(5)

"""
actually it dosen't make any sense in using so many .next notaion so we will solve this in next program
Observe that each link node is refrenced with the head node.
printing the node itself is a tedious task. so we will create a function for that.
"""

print(head)
print(head.value)
print(head.next)
print(head.next.value)
print(head.next.next)

print(head.next.value)
print(head.next.next.value)
print(head.next.next.next.value)


