# create a link list using a list.
# and using a function

class Node:
    def __init__(self, value):  # defining the consturctors
        self.value = value  # assignig the data in the node.
        self.next = None  # assigning None since it is not pointing to any other link.


def print_ll(head):
    current_node = head
    while current_node != None:  # iteration through the nodes.
        print(current_node.value)  # prints the current node value
        current_node = current_node.next  # sets the temp node variable with next noode


class LinkedList:
    def __init__(self):
        self.head = None

    def to_list(self):
        # TODO: Write function to turn Linked List into Python List
        link_to_pyhton_list = list()
        node = self.head
        while node:
            link_to_pyhton_list.append(node.value)
            node = node.next
        return link_to_pyhton_list

    def append(self, value):  # a method to add elements to the lined list.
        if self.head is None:
            self.head = Node(value)
            return

        # Move to the tail (the last node)
        node = self.head
        while node.next:
            node = node.next

        node.next = Node(value)
        return

    def prepend(self, value):

        " Prepend a value to the beginning of the list. "
        # TODO: Write function to prepend here
        if self.head is None:
            self.head = Node(value)
            return
        else:
            newhead = Node(value)
            newhead.next = self.head
            self.head = newhead
            return


def pop(self):
    """ Return the first node's value and remove it from the list. """
    # TODO: Write function to pop here
    node = self.head
    self.head = self.head.next
    return node


LinkedList.pop = pop  # adding pop to the class


def insert(self, value, pos):
    """ Insert value at pos position in the list. If pos is larger than the
    length of the list, append to the end of the list. """

    # TODO: Write function to insert here
    if self.head is None:
        self.head = Node(value)
        return
    elif pos == 0:
        self.prepend(value)
    position = 0
    node = self.head
    while node.next and position <= pos:
        if pos - 1 == position:
            temp_node = node.next
            node.next = Node(value)
            node.next.next = temp_node
            return
        node = node.next
        position += 1
    else:
        self.append(value)


LinkedList.insert = insert


def size(self):
    """ Return the size or length of the linked list. """
    # TODO: Write function to get size here
    current_node = self.head
    count = 0
    while current_node is not None:
        count += 1
        current_node = current_node.next
    return count


LinkedList.size = size

linked_list = LinkedList()  # creating the object
linked_list.append(1)  # appending the 6 to already created linked list.
linked_list.append(2)
linked_list.append(3)
linked_list.append(4)

print_ll(linked_list.head)
print('The firsnt node which is popped out is', linked_list.pop().value, sep=": ")
print('the new updated linked list is: ')
print_ll(linked_list.head)

# insert command
linked_list.insert(6, 1)
print('The new updated linked list after insertion of {} is: '.format("6"))
print_ll(linked_list.head)

print('The size of the linked list is: ', linked_list.size())
assert linked_list.size() == 5, f"list contents: {linked_list.to_list()}"
