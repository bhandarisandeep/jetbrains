class Node:
    def __init__(self, value):  # defining the consturctors
        self.value = value  # assignig the data in the node.
        self.next = None  # assigning None since it is not pointing to any other link.


def print_ll(head):
    current_node = head
    while current_node != None:  # iteration through the nodes.
        print(current_node.value)   # prints the current node value
        current_node = current_node.next # sets the temp node variable with next noode


head = Node(2)  # defing the head node. always rember the head.
head.next = Node(3)
head.next.next = Node(4)
head.next.next.next = Node(5)

print_ll(head)
