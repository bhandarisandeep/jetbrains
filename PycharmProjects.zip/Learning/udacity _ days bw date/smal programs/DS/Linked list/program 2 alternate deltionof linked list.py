
"""
You are given the head of a linked list and two integers, i and j. You have to retain the first i nodes and then delete the next j nodes. Continue doing so until the end of the linked list.

Example:

linked-list = 1 2 3 4 5 6 7 8 9 10 11 12
i = 2
j = 3
Output = 1 2 6 7 11 12
"""
# LinkedList Node class for your reference
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


# helper functions for testing purpose
def create_linked_list(arr):
    if len(arr)==0:
        return None
    head = Node(arr[0])
    tail = head
    for data in arr[1:]:
        tail.next = Node(data)
        tail = tail.next
    return head

def print_linked_list(head):
    while head:
        print(head.data, end=' ')
        head = head.next
    print()


def skip_i_delete_j(head, i, j):
    """
    :param: head - head of linked list
    :param: i - first `i` nodes that are to be skipped
    :param: j - next `j` nodes that are to be deleted
    return - return the updated head of the linked list
    """
    if head is None:
        return head

    counter = 0
    node = head
    newhead = head
    newtail = newhead
    print_linked_list(node)
    print(type(node))
    print(type(head))
    while node.next:
        while counter < i:
            node = node.next
            newtail.next = node
            newtail = newtail.next
        counter = 0
        while counter < j:
            node = node.next
        counter = 0
        node = node.next
    return newhead


arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
i = 2
j = 2
head = create_linked_list(arr)
# solution = [1, 2, 5, 6, 9, 10]
solvedhead = skip_i_delete_j(head, i ,j)
print_linked_list(solvedhead)

