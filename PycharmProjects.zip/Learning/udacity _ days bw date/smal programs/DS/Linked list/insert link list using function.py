# create a link list using a list.
# and using a function

class Node:
    def __init__(self, value):  # defining the consturctors
        self.value = value  # assignig the data in the node.
        self.next = None  # assigning None since it is not pointing to any other link.


def print_ll(head):
    current_node = head
    while current_node != None:  # iteration through the nodes.
        print(current_node.value)   # prints the current node value
        current_node = current_node.next # sets the temp node variable with next noode


def create_linked_list(input_list):
    head = None # condition for an empty list
    if len(input_list):
        head = Node(input_list[0])
        temp_head = head
        for i in range(1,len(input_list)):
            temp_head.next = Node(input_list[i])
            # print(temp_head.next.value)
            temp_head = temp_head.next
        temp_head.next = None
    return head
# the time compleity is O(n)

    # manually adding the elements in the linked list.
head = Node(2)  # defing the head node. always rember the head.
head.next = Node(3)
head.next.next = Node(4)
head.next.next.next = Node(5)

# print_ll(head)


input_list = [1,2,3,4,5]
# adding the data in the lists using function.
create_linked_list(input_list)
print_ll(create_linked_list(input_list))

print(create_linked_list([]))


"""
udacity solution: mines more effective

def create_linked_list(input_list):
    head = None
    for value in input_list:
        if head is None:
            head = Node(value)    
        else:
        # Move to the tail (the last node)
            current_node = head
            while current_node.next:
                current_node = current_node.next
        
            current_node.next = Node(value)
    return head
# the time compleity is O(n ** 2)

*****************************************************

Udacity O(n) improved solution:

def create_linked_list_better(input_list):
    
    head = None
    tail = None
    
    for value in input_list:
        # if a only a single element is there so head and tail are the same
        if head is None:
            head = Node(value)
            tail = head            
        else:
        # from the second iteration if more than one element is present in the list 
        # then we need to update the tail node only.
        # so we update the tail node to the lat iteration of the list.
            tail.next = Node(value)
            tail = tail.next        # update the tail
            
    return head
"""
