"""
Usually you'll want to create a LinkedList class as a wrapper
for the nodes themselves and to provide common methods that operate on the list.
For example you can implement an append method that adds a value to the end of the list.
Note that if we're only tracking the head of the list, this runs in linear time -  𝑂(𝑁)  -
 since you have to iterate through the entire list to get to the tail node. However,

 prepending (adding to the head of the list) can be done in constant  𝑂(1)  time.
 You'll implement this prepend method in the Linked List
"""
# Add a method to_list() to LinkedList that converts a linked list back into a Python list.
class Node:
    def __init__(self, value):  # defining the consturctors
        self.value = value  # assignig the data in the node.
        self.next = None  # assigning None since it is not pointing to any other link.


def print_ll(head):
    current_node = head
    while current_node != None:  # iteration through the nodes.
        print(current_node.value)   # prints the current node value
        current_node = current_node.next # sets the temp node variable with next noode


"""linked list class that will create and append the node in the linked list."""
class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, value): # a method to add elements to the lined list.
        if self.head is None:
            self.head = Node(value)
            return

        # Move to the tail (the last node)
        node = self.head
        while node.next:
            node = node.next

        node.next = Node(value)
        return

    def to_list(self):
        # TODO: Write function to turn Linked List into Python List
        link_to_pyhton_list = list()
        node = self.head
        while node:
            link_to_pyhton_list.append(node.value)
            node = node.next
        return link_to_pyhton_list



linked_list = LinkedList() # creating the object
linked_list.append(1) # appending the 6 to already created linked list.
linked_list.append(2)
linked_list.append(3)
linked_list.append(4)

print_ll(linked_list.head)


"""
# method to print ll
node = linked_list.head
while node:
    print(node.value)
    node = node.next
"""

python_list = linked_list.to_list()
print(python_list)
