# create a link list using a list.
# and using a function

class Node:
    def __init__(self, value):  # defining the consturctors
        self.value = value  # assignig the data in the node.
        self.next = None  # assigning None since it is not pointing to any other link.


def print_ll(head):
    current_node = head
    while current_node != None:  # iteration through the nodes.
        print(current_node.value)  # prints the current node value
        current_node = current_node.next  # sets the temp node variable with next noode


class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, value):  # a method to add elements to the lined list.
        if self.head is None:
            self.head = Node(value)
            return

        # Move to the tail (the last node)
        node = self.head
        while node.next:
            node = node.next

        node.next = Node(value)
        return


def search(self, value):
    """ Search the linked list for a node with the requested value and return the node. """
    # TODO: Write function to search here
    if self.head is None:
        return None
    else:
        curnode = self.head
        while curnode:
            if curnode.value == value:
                return curnode
            else:
                curnode = curnode.next
        return None


LinkedList.search = search


def remove(self, value):
    """ Remove first occurrence of value. """
    # TODO: Write function to remove here
    if self.head is None:
        return
    if self.head.value == value:
        self.head = self.head.next
    else:
        cur_node = self.head
        while cur_node.next:
            if cur_node.next.value == value:
                cur_node.next = cur_node.next.next
                return
            cur_node = cur_node.next

LinkedList.remove = remove


# print_ll(head)

linked_list = LinkedList() # creating the object
linked_list.append(1) # appending the 6 to already created linked list.
linked_list.append(2)
linked_list.append(3)
linked_list.append(4)

print_ll(linked_list.head)

print('the node value of searched value is',linked_list.search(2).value, sep=":::")

linked_list.remove(2) # removing the node of 2

print_ll(linked_list.head)
