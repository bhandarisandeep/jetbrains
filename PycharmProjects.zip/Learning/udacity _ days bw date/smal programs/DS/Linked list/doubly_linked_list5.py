class DoubleNode:
    def __init__(self,value):
# construction but have three constructor variables
        self.value = value
        self.next = None
        self.previous = None

class DoubleLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
        # defining the head and tail constructor.

    def append(self, value):
        if self.head is None:
            self.head = DoubleNode(value)
            self.tail = self.head # the first element would be the tail as well so tails is also the head
            return
        else:
            self.tail.next = DoubleNode(value)  # updating the next tail node
            self.tail.next.previous = self.tail # updating the previous node of the "next tail node"
            self.tail = self.tail.next          # updating the tail node

            # iteration to the last node is not required since we have a tail element as well .
            return


linked_list = DoubleLinkedList()
linked_list.append(1)
linked_list.append(-2)
linked_list.append(4)

print("Going forward through the list, should print 1, -2, 4")
node = linked_list.head
while node:
    print(node.value)
    node = node.next

print("\nGoing backward through the list, should print 4, -2, 1")
node = linked_list.tail
while node:
    print(node.value)
    node = node.previous
