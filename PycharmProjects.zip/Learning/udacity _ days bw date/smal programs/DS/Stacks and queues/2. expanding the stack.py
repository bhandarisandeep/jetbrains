# implement the _handle_stack_capacity_full
# Add a size method that returns the current size of the stack
# Add an is_empty method that returns True if the stack is empty and False otherwise


class Stack():
    def __init__(self, stack_length=10):  # default stack lenth to 10 units
        self.arr = [0 for _ in range(stack_length)]  # list comprehension to fill the 0 or None as every stack element.
        self.next_index = 0  # index for the top of the array, points to the top, right now for empty stack its 0
        self.num_elements = 0  # keep the counts of the elements.

    # Add the push method
    def push(self, value):
        if self.next_index == len(self.arr):
            # checking if the stack is full.
            print("Out of space! Increasing array capacity ...")
            self._handle_stack_capacity_full()
        self.arr[self.next_index] = value
        self.next_index += 1
        self.num_elements += 1

    def _handle_stack_capacity_full(self):
        old_arr = self.arr
        self.arr = [0 for _ in range(2 * len(old_arr))]  # size double
        # now we have to update the stack with the old elements
        for index, value in enumerate(old_arr):
            self.arr[index] = value

    def size(self):
        return self.num_elements

    def is_empty(self):
        return True if self.next_index is 0 else False

    def pop(self):
        if self.is_empty():
            self.next_index = 0
            return None
        self.next_index -= 1
        self.arr[self.next_index] = 0
        self.num_elements -= 1
        return self.arr[self.next_index]


"""what will happen if the stack is at it's limit of filling elements. for that we need to to define a function which will check the 
limit of the stack and send stack is full message. 
error gicen in full stack: IndexError: list assignment index out of range(stack overflow"""


foo = Stack()
print(foo.is_empty())
print(foo.arr)
for i in range(1,5):
    foo.push(i)
    print(foo.arr)
print(foo.arr)

print(foo.size())
print(foo.is_empty())

foo.pop()
print(foo.arr)
print(foo.size())
