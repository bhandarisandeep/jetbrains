# Create and initialize the Stack class

class Stack():
    def __init__(self, stack_length=10):  # default stack lenth to 10 units
        self.arr = [0 for _ in range(stack_length)]  # list comprehension to fill the 0 or None as every stack element.
        self.next_index = 0  # index for the top of the array, points to the top, right now for empty stack its 0
        self.num_elements = 0  # keep the counts of the elements.


    #Add the push method
    def push(self,value):
        self.arr[self.next_index] = value
        self.next_index += 1
        self.num_elements += 1


"""what will happen if the stack is at it's limit of filling elements. for that we need to to define a function which will check the 
limit of the stack and send stack is full message. 
error gicen in full stack: IndexError: list assignment index out of range(stack overflow"""

foo = Stack()
print(foo.arr)
foo.push(1)
print(foo.arr)
