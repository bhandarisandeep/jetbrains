def word_flipper(our_string):

    """
    Flip the individual words in a sentence

    Args:
       our_string(string): String with words to flip
    Returns:
       string: String with words flipped
    """

    # TODO: Write your solution here
    world_list = our_string.split()
    new_string = ""
    for word in world_list:
        for letter in range(1, len(word) + 1):
            new_string += word[-letter]
        new_string += " "
    print(new_string)

# word_flipper(input())
print ("Pass" if ('sihT si na elpmaxe' == print(word_flipper('This is an example'))) else "Fail")

