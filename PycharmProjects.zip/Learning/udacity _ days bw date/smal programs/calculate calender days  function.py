def readable_timedelta(days):
    week = 7
    weeks = days // week
    left_days = days % week
    if left_days:
        return "{} week(s) and {} day(s).".format(weeks, left_days)
    else:
        return "{} week(s)".format(weeks)

days = int(input("Input Number of days: \n"))
print(readable_timedelta(days))
