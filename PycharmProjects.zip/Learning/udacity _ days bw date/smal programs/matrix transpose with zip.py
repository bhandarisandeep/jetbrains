data = ((0, 1, 2), (3, 4, 5), (6, 7, 8), (9, 10, 11))
r1, r2, r3 = zip(*data)
data_transpose = (r1 ,r2, r3)
# replace with your code
print(data_transpose)
