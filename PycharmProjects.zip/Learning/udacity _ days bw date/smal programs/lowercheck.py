names = ["Joey Tribbiani", "Monica Geller", "Chandler Bing", "Phoebe Buffay"]

for i in range(len(names)):
    name = names[i].lower().replace(" ", "_")
    names[i] = name
print(names)
